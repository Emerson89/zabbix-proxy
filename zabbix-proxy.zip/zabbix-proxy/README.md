zabbix-proxy
=========

Requerimentos
------------
Nenhum 

Versão Zabbix
--------------

    Para utilizar a versão zabbix_version: 4.0.3 utilize a v1.0
    Versão atual 4.4.9

Versão do zabbix-proxy a ser instalado.


Dependencias
------------

As seguintes roles são dependencias da role zabbix-proxy:

    mysql

Playbook Exemplo
----------------
```
---
- hosts: all
  roles:
    - zabbix
  become: yes
  
```


Variáveis de customização do Zabbix Proxy
----------------
Localização: roles/zabbix/defaults/main.yml 

```
 zabbix_proxy_mysql_version: '4.4.9'
 zabbix_server_ip: 'ip-zabbix-server'
 zabbix_hostname: "{{ ansible_hostname }}"
 zabbix_hostmetadata: 'os-linux'
```


  

Informação importante 
----------------

Para que esta role funcione 100% é recomendado que o zabbix-server de destino atenda a mesma versão. Entretanto ,caso a versão
do zabbix-server de destino não atenda aos requisitos descritos acima, é possível personalizar a versão na variavel localizada em :

  roles/zabbix/defaults/main.yml : 
    {...}
    zabbix_proxy_mysql_version: '4.4.9'
    {...}

Necessário também atualizar o link do repositório na seguinte task : 
  roles/zabbix/tasks/main.yml :
```
  
  
      - name: Instalando repo zabbix proxy 
      ignore_errors: yes
      yum:
          state: present
          name: "{{ item }}"

      with_items: 
          
            - https://repo.zabbix.com/zabbix/4.4/rhel/7/x86_64/zabbix-proxy-mysql-4.4.9-1.el7.x86_64.rpm
 
```

  
Licença
-------

BSD

Informações sobre o autor
------------------

Esta role foi desenvolvida baseada na receita de instalação do zabbix server criada por Jonathan Guedes (jonathan.bezerra@rivendel.com.br) e refatorada por Renan Marcos de Amorim(renan.amorim@rivendel.com.br) em 01/2018. Atualização de versão para 4.4 realizado pelo Emerson Cesario
